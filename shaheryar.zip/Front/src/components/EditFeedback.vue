<template>
    <div class="row">
        <div class="col-md-8 mx-auto" v-if="isMounted">
          <h2 class="mt-3">Edit Feedback</h2>
            <div class="mt-3">
              <div class="form-group">
                <label for="title">Title</label>
                <input type="text" class="form-control" id="title" v-model="feedback.title">
              </div>
                <div class="form-group">
                  <label for="category">Category</label>
                  <select class="form-control" id="category" v-model="feedback.category_id">
                    <option v-for="category in categories" :key="category.id" :value="category.id">{{ category.name }}</option>
                  </select>
                </div>
              <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" rows="3" v-model="feedback.description"></textarea>
              </div>
                <button type="submit" class="btn btn-primary" @click.prevent="updateFeedback()">Submit</button>
            </div>
        </div>
    </div>
</template>
<script>
  import { mapState } from 'vuex';
  export default {
    name: 'EditFeedback',
    data(){
      return {
        isMounted:false,
        feedback: {
          title: '',
          category_id: null,
          description: ''
        }
      }
    },
    computed: {
      ...mapState({
        categories: state => state.feedback.category,
      }),
    },
    mounted(){
      this.getFeedback();
    },
    methods: {
    getFeedback() {
      const feedbackId = this.$route.params.id;
      this.$store.dispatch('feedback/getFeedback',feedbackId)
      .then((res) =>{
        this.feedback = res.feedback;
        this.isMounted = true;
      })
      .catch((error) =>{
        console.log(error)
        this.$router.push('/');
      })
    },
    updateFeedback(){
      this.$store.dispatch('feedback/updateFeedback',this.feedback)
      .then(() => {
        this.$router.push('/');
      })
      
    }

  }
    
  }
</script>