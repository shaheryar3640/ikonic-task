export default {
    feedback:[],
    category:[],
    allUser:[],
    feedbackeditModal:false,
    feedbackAddModal:false,
    getFeedbackApiCall:false
}