<template>
    <div class="mt-3" v-if="isMounted">
      <!-- Feedback Post -->
      <div class="feedback-post">
        <div class="feedback-content">
          <h1>{{ feedback.title }}</h1>
          <p v-if="feedback.user">Posted by: {{ feedback.user.name }}</p>
          <p>Description: {{ feedback.description }}</p>
        </div>
      </div>
      
      <!-- Comment Section -->
      <div class="comment-section">
        <div class="comment-input">
          <textarea v-model="commentText" @input="handleInput" class="comment-textarea" placeholder="Write your comment here"></textarea>
          <div v-if="showUserList" class="user-list" style="margin-top: 40px;">
            <input v-model="searchQuery" class="search-input" type="text" placeholder="Search users">
            <ul style="width: 300px; height: 200px;">
              <li v-for="user in filteredUsers" :key="user" @click="insertUser(user.name)">{{ user.name }}</li>
            </ul>
          </div>
          <button @click="addComment" class="comment-button">Post Comment</button>
        </div>
  
        <h2 class="comment-section-title">Join the Discussion</h2>
        <div class="comments">
          <ul class="comment-list">
            <li v-for="comment in comments" :key="comment.id" class="comment">
                <CommentItem :comment="comment" />
            </li>
          </ul>
        </div>
      </div>
    </div>
  </template>
  
  <script>
    import CommentItem from '@/components/CommentItem.vue'
  export default {
    name: 'FeedbackComment',
    components:{
        CommentItem
    },
    data() {
      return {
        isMounted: false,
        comments: [],
        commentText: '',
        replyText: '',
        feedback: {},
        showUserList: false,
        userList: ["aa","qqq","qqqqq"],
        searchQuery: '',
      }
    },
    computed:{
      allUser: function() {
        return this.$store.state.feedback.allUser;
      },
      filteredUsers() {
        return this.allUser.filter(user => user.name.toLowerCase().includes(this.searchQuery.toLowerCase()));
      },
      getFeedbackApi(){
        return this.$store.state.feedback.getFeedbackApiCall
      }
    },
    mounted() {
      this.getFeedback();
    },
    watch:{
      '$store.state.feedback.getFeedbackApiCall'(newValue, oldValue) {
        if (newValue && newValue !== oldValue && this.isMounted) {
            this.getFeedback();
        }
      }
	},
    methods: {
      handleInput() {
        const lastChar = this.commentText.slice(-1);
        if (lastChar === '@') {
          this.showUserList = true;
        } 
        // else {
        //   this.showUserList = false;
        // }
      },
    insertUser(user) {
      const textBeforeAtSymbol = this.commentText.slice(0, -1);
      this.commentText = textBeforeAtSymbol + user + ' ';
      this.showUserList = false;
    },
    getFeedback() {
      this.$store.state.feedback.getFeedbackApiCall = false;
        const feedbackId = this.$route.params.id;
        this.$store.dispatch('feedback/feedbackComment', feedbackId)
          .then((res) => {
            this.getAllUser();
            this.feedback = res.feedback;
            this.comments = res.feedback.comments
            this.isMounted = true;
          })
          .catch((error) => {
            console.log(error)
            this.$router.push('/');
          })
      },
      getAllUser() {
        this.$store.dispatch('feedback/getAllUser')
      },
      addComment() {
        if (this.commentText.trim() !== '') {
          // this.comments.push({
          //   id: this.comments.length + 1,
          //   text: this.commentText,
          //   replies: [],
          // });
          
          let payload = {
            feedback_id: this.feedback.id,
            comment: this.commentText,
          }
          this.$store.dispatch('feedback/saveComment', payload)
          .then(() => {
            this.getFeedback()
          })
          .catch((error) => {
            console.log(error)
            this.$router.push('/');
          })
          this.commentText = '';
        }
      },
    }
  }
  </script>
  
  <style scoped>
    .search-input {
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      width: 300px;
    }
    .blue-text {
      color: blue;
    }
    .normal-text {
      color: inherit;
    }
  .feedback-post {
    margin-bottom: 40px;
    padding: 20px;
    background-color: #f0f0f0;
    border-radius: 10px;
  }
  
  .feedback-content {
    margin-bottom: 15px;
  }
  
  .comment-section {
    font-family: Arial, sans-serif;
    max-width: 600px;
    margin: 0 auto;
  }
  
  .comment-section-title {
    font-size: 36px;
    font-weight: bold;
    color: #333;
    text-align: center;
    margin-bottom: 40px;
  }
  
  .comment {
    margin-bottom: 10px;
    padding: 10px;
    border-radius: 10px;
  }
  
  .comment .text {
    margin-bottom: 15px;
  }
  
  .comment-input {
    margin-top: 40px;
    display: flex;
    flex-direction: column;
  }
  
  .comment-textarea {
    width: 100%;
    height: 150px;
    padding: 15px;
    border-radius: 10px;
    border: 1px solid #ccc;
    resize: none;
    font-size: 16px;
    margin-bottom: 20px;
  }
  
  .comment-button {
    width: 200px;
    height: 50px;
    border: none;
    border-radius: 10px;
    background-color: #007bff;
    color: #fff;
    font-size: 18px;
    cursor: pointer;
    align-self: flex-end;
    transition: background-color 0.3s ease;
  }
  
  .comment-button:hover {
    background-color: #0056b3;
  }
  
  .nested-comments {
    margin-left: 30px;
    list-style-type: none; /* Removes bullet points from nested comments */
  }
  
  .nested-comments, .comments li {
    list-style: none;
  }
  .feedback-post {
  padding: 20px;
  background: linear-gradient(135deg, #ffffff, #f0f0f0);
  border-radius: 15px;
  box-shadow: 0 2px 5px rgba(10, 10, 10, 0.1);
}

.feedback-content {
  margin-bottom: 15px;
}

.feedback-content h1 {
  font-size: 24px;
  font-weight: bold;
  color: #242424;
}

.feedback-content p {
  font-size: 16px;
  color: #313131;
}

.user-list {
  position: absolute;
  background: white;
  border: 1px solid #ccc;
  max-height: 200px;
  overflow-y: auto;
}

.user-list ul {
  padding: 0;
  margin: 0;
}

.user-list li {
  list-style: none;
  cursor: pointer;
  padding: 5px;
}

.user-list li:hover {
  background-color: #f0f0f0;
}
  </style>
  