<template>
    <div class="container-fluid">
        <nav class="navbar navbar-light bg-light">
            <router-link class="navbar-brand" to="/">Home</router-link>
            <!-- <form class="form-inline"> -->
              <button class="btn btn-outline-success my-2 my-sm-0" type="submit" @click.prevent="logOut">Logout</button>
            <!-- </form> -->
          </nav>
    </div>
</template>

<script>
    export default {
        name : "navBar",
        methods:{
            logOut(){
                this.$store.dispatch('login/logOut')
                .then(() => {
                    this.$router.push('/login')
                })
                
            }
        }
    }
</script>