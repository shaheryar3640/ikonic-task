<template>
    <div class="row">
        <div class="col-md-8 mx-auto" v-if="isMounted">
          <h2 class="mt-3">Add Feedback</h2>
            <div class="mt-3">
              <div class="form-group">
                <label for="title">Title</label>
                <input type="text" class="form-control" id="title" v-model="feedback.title">
              </div>
                <div class="form-group">
                  <label for="category">Category</label>
                  <select class="form-control" id="category" v-model="feedback.category_id">
                    <option v-for="category in categories" :key="category.id" :value="category.id">{{ category.name }}</option>
                  </select>
                </div>
              <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" rows="3" v-model="feedback.description"></textarea>
              </div>
                <button type="submit" class="btn btn-primary" @click.prevent="addFeddback()">Submit</button>
            </div>
        </div>
    </div>
</template>
<script>
  import { mapState } from 'vuex';
  export default {
    name: 'AddFeedback',
    data(){
      return {
        isMounted:false,
        feedback: {
          title: '',
          category_id: null,
          description: ''
        }
      }
    },
    computed: {
      ...mapState({
        categories: state => state.feedback.category,
      }),
    },
    mounted(){
      this.getAllCategories();
    },
    methods: {
    getAllCategories() {
      this.$store.dispatch('feedback/getAllCategory')
      .then(() =>{
        this.isMounted = true;
      })
    },
    addFeddback(){
      this.$store.dispatch('feedback/storeFeedback',this.feedback)
      .then(() => {
        this.$router.push('/');
      })
    }

  }
    
  }
</script>