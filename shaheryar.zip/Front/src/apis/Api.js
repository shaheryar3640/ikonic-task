import axios from "axios";
const api_url = process.env.VUE_APP_ENV_VARIABLE
const Api = axios.create({
    baseURL : `${api_url}/api`,
});
// const token = localStorage.getItem('token');
// if (token) {
//     axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
// }
// axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token')
export default Api;