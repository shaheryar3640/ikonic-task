export const setFeedback = (state, feedback) => {
    state.feedback = feedback;
}
export const setCategory = (state, category) => {
    state.category = category;
}
export const RemoveFeedback = (state, id) => {
    state.feedback.data = state.feedback.data.filter(item => item.id !== id.id);
}

export const setAllUser = (state, user) => {
    state.allUser = user;
}
