export const getFeedback = (state) => {
    return state.feedback;
}

export const getCategory = (state) => {
    return state.category;
}

export const getAllUser = (state) => {
    return state.allUser;
}