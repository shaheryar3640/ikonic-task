<template>
    <div class="row">
        <div class="col-md-8 mx-auto">
          <p>{{ message }}</p>
          <h2 class="mb-4">Student</h2> <router-link to="/AddStudent" class="btn btn-primary" >Add Student</router-link>
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">name</th>
                <th scope="col">price</th>
                <th scope="col">action</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(product,index) in products" v-bind:key="index">
                <th scope="row">{{index+1}}</th>
                <td>{{product.name}}</td>
                <td>{{product.price}}</td>
                <td><button type="submit" class="btn btn-sm btn-primary">Edit</button> | 
                  <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

</template>

<script>
    export default {
        name: 'ShowStudent',
        data(){
      return {
        name : 'abc'
      }
    },
    computed:{
      products(){
        return this.$store.getters.getProducts;
      },
      message(){
        return this.$store.state.message;
      }
    },
    mounted(){
      this.name = '123'
    },
    created(){
      this.name = 'qw'
    },
    methods: {
      chVal() {
        this.name = 'qwerty';
        let payload = {
              id: 3,
              name: "qwerty",
              price: 200,
              shortdesc: "Best Drip in the Market",
              url: "images/chelsea-shoes.png"
            };
            this.$store.dispatch('addPro',payload);
        alert(this.name);
      }
    }

    }
</script>