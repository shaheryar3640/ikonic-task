<template>
    <div>
      <div class="comment-avatar"></div>
    <div class="comment-content">
      <div class="comment-header">
        <!-- <span class="user-name">By: </span> -->
        <div>
          <span class="comment-user">{{comment.user.name}} {{this.$store.state.feedback.getFeedbackApiCall}}</span>
        </div>
        <div>
          <span class="comment-date"> {{ formatDate(comment.created_at) }}</span>
        </div>
      </div>
      
      <div class="comment-text">{{ comment.comment }}</div>
      <button @click="toggleReplyInput" class="reply-button">Reply</button>
      <!-- Reply Input -->
      <div v-if="showReplyInput" class="reply-input">
        <textarea v-model="replyText" class="reply-textarea" placeholder="Write your reply here"></textarea>
        <button @click="postReply(comment)" class="post-reply-button">Post Reply</button>
      </div>
    </div>
      <ul class="nested-comments">
        <li v-for="reply in comment.replies" :key="reply.id" class="comment">
          <comment-item :comment="reply" />
        </li>
      </ul>
    </div>
  </template>
  
  <script>
    import moment from 'moment';
  export default {
    name: 'CommentItem',
    props: {
      comment: Object
    },
    data() {
      return {
        showReplyInput: false,
        replyText: ''
      };
    },
    methods:{
      formatDate(dateTime) {
        // return moment(dateTime).format('YYYY-MM-DD HH:mm:ss');
        return moment(dateTime).fromNow();
      },
      toggleReplyInput() {
        this.showReplyInput = !this.showReplyInput;
      },
      postReply(comment) {
        let payload = {
          comment:this.replyText,
          feedback_id:comment.feedback_id,
          parent_id:comment.id,
        };
        console.log(this.replyText,"Reply posted:", comment);
        console.log('payload',payload)
        this.$store.dispatch('feedback/saveNewComment',payload)
        .then(()=>{
          this.$store.state.feedback.getFeedbackApiCall = true;
          console.log("Reply postedasasass:");
          this.replyText = '';
          this.showReplyInput = false;
          
        })
        
      }
    }
  }
  </script>
  
<style scoped>
 .comment {
    margin-bottom: 15px; /* Add margin between comments */
  }

.comment .text {
  padding: 15px;
  background-color: #f0f0f0;
  border-radius: 10px;
  margin-bottom: 10px;
}

.nested-comments {
  padding-left: 20px;
}

.nested-comment {
  margin-left: auto; /* Align child comments to the right */
}

.nested-comment .text {
  background-color: #f8f8f8; /* Different background color for child comments */
}
.comment-list {
  list-style-type: none;
  padding: 0;
}

.comment {
  margin-bottom: 20px;
}

.comment-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%; /* Create circular shape */
  background-color: #e3e3e3; /* Background color for the circle */
  float: left;
  margin-right: 18px; /* Adjust spacing as needed */
  margin-bottom: 5px;
}

.comment-content {
  overflow: hidden; /* Clear floats */
}

.comment-header {
  margin-bottom: 5px;
}

.user-name {
  font-weight: bold;
  font-size: 14px;
}

.comment-user {
  color: #999;
  font-size: 0.9em;
}
.comment-date{
  color: #999;
  font-size: 0.7em;
}

.comment-text {
  margin-bottom: 10px;
}

.nested-comments {
  list-style-type: none;
  padding-left: 20px;
}
.reply-button {
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 5px 10px;
  cursor: pointer;
}

.reply-input {
  margin-top: 10px;
}

.reply-textarea {
  width: 100%;
  height: 100px;
  margin-top: 5px;
  margin-bottom: 5px;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.post-reply-button {
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 5px 10px;
  cursor: pointer;
  margin-top: 5px;
}

  </style>
  