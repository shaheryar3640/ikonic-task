import { createStore } from 'vuex'
import login from './modules/login';
import feedback from './modules/feedback';


export default createStore({
  modules:{
      login,
      feedback
  },
  state:{
    toastAlert:false,
  },
  getters:{},
  mutations:{
    toastAlert(state, toastAlert){
        state.toastAlert = toastAlert;
    }
  },
  actions:{},
});