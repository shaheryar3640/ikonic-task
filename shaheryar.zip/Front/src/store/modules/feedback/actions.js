import Api from "@/apis/Api";


export const getAllFeedback = async ({ commit, rootState }, page = 1) => {

    try {
        const response = await Api.get(`/all-feedback?page=${page.page}`, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            // console.log(response.data.data)
            commit('setFeedback', response.data.data);
        }
    } catch (error) {
        console.error("Error fetching feedback:", error);
    }
};

export const getAllCategory= async ({ commit, rootState }) => {

    try {
        const response = await Api.get(`/all-category`, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            commit('setCategory', response.data.data);
        }
    } catch (error) {
        console.error("Error fetching:", error);
    }
};

export const storeFeedback = async ({ commit, rootState }, payload) => {

    try {
        const response = await Api.post('/create/feedback',payload, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            let responseMessage = {
                status: response.status,
                message: response.data.message
            }
            commit("toastAlert", responseMessage, { root: true });
            return response;
        }
    } catch (error) {
        console.error("Error fetching feedback:", error);
    }
};

export const getFeedback= async ({ commit, rootState },id) => {

    try {
        const response = await Api.get(`/show/feedback/${id}`, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            console.log('response',response)
            commit('setCategory', response.data.category);
            return response.data;
        }
    } catch (error) {
        let responseMessage = {
            status: '500',
            error: 'Something went wrong!'
        }
        commit("toastAlert", responseMessage, { root: true });
        console.error("Error fetching:", error);
    }
};

export const updateFeedback = async ({ commit, rootState }, payload) => {

    try {
        const response = await Api.post('/update/feedback',payload, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            let responseMessage = {
                status: response.status,
                message: response.data.message
            }
            commit("toastAlert", responseMessage, { root: true });
            return response;
        }
    } catch (error) {
        console.error("Error fetching feedback:", error);
    }
};

export const deleteFeedback= async ({ commit, rootState },id) => {

    try {
        const response = await Api.post('/feedback/delete',id, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            commit('RemoveFeedback', id);
            let responseMessage = {
                status: '200',
                message: 'Feedback deleted Successfully!'
            }
            commit("toastAlert", responseMessage, { root: true });
            return response;
        }
        return response;
    } catch (error) {
        console.error("Error fetching:", error);
    }
};

export const feedbackComment= async ({ commit, rootState },id) => {

    try {
        const response = await Api.get(`/feedback/comment/${id}`, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            console.log('response',response)
            return response.data;
        }
    } catch (error) {
        let responseMessage = {
            status: '500',
            error: 'Something went wrong!'
        }
        commit("toastAlert", responseMessage, { root: true });
        console.error("Error fetching:", error);
    }
};

export const saveComment = async ({ commit, rootState }, payload) => {

    try {
        const response = await Api.post('/create/comment',payload, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            let responseMessage = {
                status: response.status,
                message: response.data.message
            }
            commit("toastAlert", responseMessage, { root: true });
            return response;
        }
    } catch (error) {
        console.error("Error fetching feedback:", error);
    }
};

export const getAllUser = async ({ commit, rootState }) => {

    try {
        const response = await Api.get(`/all/user`, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            console.log(response.data.data)
            commit('setAllUser', response.data.data);
        }
    } catch (error) {
        console.error("Error fetching feedback:", error);
    }
};

export const saveNewComment = async ({ commit, rootState }, payload) => {

    try {
        const response = await Api.post('/create/newComment',payload, {
            headers: {
                Authorization: 'Bearer ' + rootState.login.token,
            }
        });
        if (response) {
            let responseMessage = {
                status: response.status,
                message: response.data.message
            }
            commit("toastAlert", responseMessage, { root: true });
            return response;
        }
    } catch (error) {
        console.error("Error fetching feedback:", error);
    }
};