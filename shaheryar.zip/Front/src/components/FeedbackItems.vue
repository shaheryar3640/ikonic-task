<template>
  <div class="row mt-5" v-if="isMounted">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="mb-0">Feedback List</h1>
        <router-link class="btn btn-primary" to="/addFeedback">+ Add Feedback</router-link>
      </div>
    <div class="col-md-4 mt-3" v-for="feedback in allFeedback" :key="feedback.id">
      <div class="card feedback-card">
        <div class="card-body">
          <h5 class="card-title">{{ feedback.title }}</h5>
          <h6 class="card-subtitle mb-2 text-muted">Category: {{feedback.category.name}}</h6>
          <p class="card-text">{{ feedback.description }}</p>
          &nbsp; <router-link href="#" class="btn btn-sm btn-warning" :to="'/feedbackComment/'+feedback.id">Comment</router-link>&nbsp;
          <router-link class="btn btn-sm btn-primary mr-2" v-if="isUserAuthorized(feedback.user_id)" :to="'/editFeedback/'+feedback.id">Edit</router-link> &nbsp; <a v-if="isUserAuthorized(feedback.user_id)" href="#" class="btn btn-sm btn-danger" @click.prevent="deleteFeedback(feedback.id)">Delete</a> 
        </div>
      </div>
    </div>
    <div class="col-md-12 mt-3">
      <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
          <li class="page-item" :class="{ disabled: pagination.current_page === 1 }">
            <a class="page-link" href="#" @click.prevent="getFeedback(pagination.current_page - 1)">Previous</a>
          </li>
          <li class="page-item" v-for="page in pagination.last_page" :key="page" :class="{ active: page === pagination.current_page }">
            <a class="page-link" href="#" @click.prevent="getFeedback(page)">{{ page }}</a>
          </li>
          <li class="page-item" :class="{ disabled: pagination.current_page === pagination.last_page }">
            <a class="page-link" href="#" @click.prevent="getFeedback(pagination.current_page + 1)">Next</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</template>

<script>
export default {
  name: "FeedbackItems",
  data(){
    return {
        isMounted:false,
        openEditModalBox:false
    }
  },
  computed: {
    allFeedback: function() {
      return this.$store.state.feedback.feedback.data;
    },
    pagination: function() {
      return this.$store.state.feedback.feedback;
    },
    user: function() {
      return this.$store.state.login.user;
    }
  },
  mounted() {
    this.getFeedback();
  },
  methods: {
    getFeedback(page = 1) {
      this.$store.dispatch('feedback/getAllFeedback', { page: page })
      .then(() =>{
        // this.isMounted = true;
        this.getUser();
      })
    },
    getUser() {
      this.$store.dispatch('login/getLoginUser')
      .then(() =>{
        this.isMounted = true;
      })
    },
    isUserAuthorized(feedbackUserId) {
      return feedbackUserId === this.$store.state.login.user.id;
    },
    deleteFeedback(id){
        let payload = {
            id:id
        }
        this.$store.dispatch('feedback/deleteFeedback', payload)
      .then(() =>{
        this.getFeedback();
        this.$router.push('/');
      })
    }

  }
};
</script>
  
<style scoped>
    .modal-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}

.modal-overlay {
    opacity: 0.7;
  /* position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5); 
  z-index: 9999; */
}
  .feedback-card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease;
  }
  
  .feedback-card:hover {
    transform: translateY(-5px);
  }
  
  .card-title {
    color: #333;
  }
  
  .card-text {
    color: #666;
  }
  
  .btn-primary {
    background-color: #007bff;
    border: none;
  }
  
  .btn-primary:hover {
    background-color: #0056b3;
  }
  
  .btn-primary:focus {
    box-shadow: none;
  }
</style>
  