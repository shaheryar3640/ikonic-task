export const setToken = (state, token) => {
    state.token = token;
}

export const setUser = (state, user) => {
    state.user = user;
}